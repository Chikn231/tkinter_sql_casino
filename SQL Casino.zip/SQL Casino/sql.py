import sqlite3

# User input (potentially malicious)
username = "admin"
password = "passwort"

# Safe SQL query with parameterized queries
con = sqlite3.connect("casino.db")
cur = con.cursor()

cur.execute("INSERT INTO Benutzer (Benutzername, Passwort) VALUES (?, ?)", (username, password))

print(username, password)
con.commit()
