import sqlite3 as sqlite

con = sqlite.connect("casino.db")
cur = con.cursor()

cur.execute("""
CREATE TABLE Benutzer(
    BenutzerID INTEGER PRIMARY KEY AUTOINCREMENT,
    Benutzername VARCHAR(255) NOT NULL,
    Passwort VARCHAR(255) NOT NULL,
    Registrierungsdatum DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    Kontostand DECIMAL(10, 2) DEFAULT 0.00,
    Letzteanmeldung DATETIME,
    Online BOOLEAN DEFAULT 0,
    Status VARCHAR(50) DEFAULT 'active',
    Vipstatus BOOLEAN DEFAULT 0,
    Email VARCHAR(255) UNIQUE,
    Geburtsdatum DATE,
    Adresse TEXT
)
""")

cur.execute("""
CREATE TABLE Spiele(
    SpielID INTEGER PRIMARY KEY AUTOINCREMENT,
    Spielname VARCHAR(255) NOT NULL,
    Spieltyp VARCHAR(50)
)
""")

cur.execute("""
CREATE TABLE Spielverlaeufe(
    SpielverlaufID INTEGER PRIMARY KEY AUTOINCREMENT,
    BenutzerID INT NOT NULL,
    SpielID INT NOT NULL,
    Gewinn DECIMAL(10, 2) DEFAULT 0.00,
    Einsatz DECIMAL(10, 2) DEFAULT 0.00,
    Timestamp DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (SpielID) REFERENCES Spiele(SpielID) ON DELETE CASCADE,
    FOREIGN KEY (BenutzerID) REFERENCES Benutzer(BenutzerID) ON DELETE CASCADE
)
""")

cur.execute("""
CREATE TABLE Transaktionen(
    TransaktionsID INTEGER PRIMARY KEY AUTOINCREMENT,
    BenutzerID INT NOT NULL,
    Betrag DECIMAL(10, 2) NOT NULL,
    Zahlungsart VARCHAR(50),
    Timestamp DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (BenutzerID) REFERENCES Benutzer(BenutzerID) ON DELETE CASCADE
)
""")

con.commit()
con.close()
