pip install mysql-connector-python
