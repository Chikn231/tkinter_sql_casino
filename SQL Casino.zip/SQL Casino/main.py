import mysql.connector
import tkinter as tk
from tkinter import messagebox
from datetime import datetime
import hashlib
from PIL import Image, ImageTk

# Globale Variable für den aktuellen Benutzer
current_user = None

# Verbindung zur MySQL-Datenbank herstellen
def connect_db():
    con = mysql.connector.connect(
        host='casino-sql-db.czss8444yut6.us-east-1.rds.amazonaws.com', 
        database='casino-sql-db',
        user='admin', 
        password='Jul!us1994')
    cur = con.cursor()
    cur.execute("""
    CREATE TABLE IF NOT EXISTS Benutzer (
        BenutzerID INT AUTO_INCREMENT PRIMARY KEY,
        Benutzername VARCHAR(255) UNIQUE NOT NULL,
        Passwort VARCHAR(255) NOT NULL,
        Registrierungsdatum DATETIME NOT NULL,
        Kontostand DECIMAL(10, 2) NOT NULL,
        Letzteanmeldung DATETIME,
        Online BOOLEAN NOT NULL,
        Status VARCHAR(50) NOT NULL,
        Vipstatus BOOLEAN NOT NULL,
        Email VARCHAR(255) UNIQUE NOT NULL,
        Geburtsdatum DATE,
        Adresse VARCHAR(255)
    )
    """)
    con.commit()
    return con

# Passwort hash-Funktion
def hash_password(password):
    return hashlib.sha256(password.encode()).hexdigest()

# Benutzer registrieren
def register_user(username, password, email, window):
    con = connect_db()
    cur = con.cursor()
    hashed_password = hash_password(password)
    try:
        cur.execute("""
            INSERT INTO Benutzer (Benutzername, Passwort, Registrierungsdatum, Kontostand, Letzteanmeldung, Online, Status, Vipstatus, Email, Geburtsdatum, Adresse)
            VALUES (%s, %s, %s, 0.00, NULL, 0, 'active', 0, %s, NULL, NULL)
        """, (username, hashed_password, datetime.now(), email))
        con.commit()
        messagebox.showinfo("Erfolg", "Benutzer erfolgreich registriert!")
        global current_user
        current_user = username
        window.destroy()  # Schließen des Registrierungsfensters
        update_main_menu()  # Aktualisieren des Hauptmenüfensters
    except mysql.connector.IntegrityError:
        messagebox.showerror("Fehler", "Benutzername oder E-Mail existieren bereits.")
    finally:
        con.close()

# Benutzer anmelden
def login_user(username, password, window):
    con = connect_db()
    cur = con.cursor()
    hashed_password = hash_password(password)
    cur.execute("SELECT * FROM Benutzer WHERE Benutzername=%s AND Passwort=%s", (username, hashed_password))
    user = cur.fetchone()
    con.close()
    if user:
        messagebox.showinfo("Erfolg", f"Willkommen, {username}!")
        global current_user
        current_user = username
        window.destroy()  # Schließen des Anmeldefensters
        update_main_menu()  # Aktualisieren des Hauptmenüfensters
    else:
        messagebox.showerror("Fehler", "Ungültiger Benutzername oder Passwort.")

# Registrierungsfenster
def open_register_window():
    register_window = tk.Toplevel()
    register_window.title("Registrieren")
    root.resizable(width=False, height=False)
    register_window.geometry("300x200")  # Setzt die Dimensionen des Registrierungsfensters
    
    tk.Label(register_window, text="Benutzername").pack()
    reg_username = tk.Entry(register_window)
    reg_username.pack()

    tk.Label(register_window, text="Passwort").pack()
    reg_password = tk.Entry(register_window, show="*")
    reg_password.pack()

    tk.Label(register_window, text="E-Mail").pack()
    reg_email = tk.Entry(register_window)
    reg_email.pack()

    tk.Button(register_window, text="Registrieren", command=lambda: register_user(reg_username.get(), reg_password.get(), reg_email.get(), register_window)).pack()

# Anmeldefenster
def open_login_window():
    login_window = tk.Toplevel()
    login_window.title("Login")
    login_window.geometry("300x200")  # Setzt die Dimensionen des Anmeldefensters
    root.resizable(width=False, height=False)
    tk.Label(login_window, text="Benutzername").pack()
    login_username = tk.Entry(login_window)
    login_username.pack()

    tk.Label(login_window, text="Passwort").pack()
    login_password = tk.Entry(login_window, show="*")
    login_password.pack()

    tk.Button(login_window, text="Login", command=lambda: login_user(login_username.get(), login_password.get(), login_window)).pack()
    tk.Button(login_window, text="Registrieren", command=open_register_window).pack()

# Hauptmenüfenster
def open_main_menu():
    global root
    root = tk.Tk()
    root.title("Hauptmenü")
    root.resizable(width=False, height=False)
    width, height = 1040, 600  # Dimensionen des Hauptfensters
    root.geometry(f"{width}x{height}")  # Setzt die Dimensionen des Hauptmenüfensters
    root.configure(background="#dbf951")

    # Zentrierung des Fensters
    screen_width = root.winfo_screenwidth()
    screen_height = root.winfo_screenheight()
    x = (screen_width // 2) - (width // 2)
    y = (screen_height // 2) - (height // 2)
    root.geometry(f'{width}x{height}+{x}+{y}')
    
    # Erstellen von Widgets
    create_main_menu_widgets()

    root.mainloop()

# Widgets für das Hauptmenüfenster erstellen
def create_main_menu_widgets():
    global login_button
    # Anmelden-Knopf oben links oder Benutzername
    if current_user:
        login_label = tk.Label(root, text=f"Angemeldet als: {current_user}")
        login_label.place(x=10, y=10)
    else:
        login_button = tk.Button(root, text="Anmelden", command=open_login_window)
        login_button.place(x=10, y=10)

    def box_command(box_number):
        if current_user:
            messagebox.showinfo("Info", f"Box {box_number} geöffnet")
        else:
            blink_button(login_button, 5)
            messagebox.showerror("Fehler", "Zuerst Anmelden, um zu spielen!")

    # Vier große Boxen mit Bildern
    box_width, box_height = 200, 390  # Setzen Sie die gewünschte Größe der Boxen
    try:
        images = [
            Image.open("images/slots.png").resize((box_width, box_height)),
            Image.open("images/blackjack.png").resize((box_width, box_height)),
            Image.open("images/roulette.png").resize((box_width, box_height)),
            Image.open("images/clucknboom.png").resize((box_width, box_height))
        ]
        photo_images = [ImageTk.PhotoImage(img) for img in images]

        for i in range(1, 5):
            box = tk.Button(root, image=photo_images[i-1], command=lambda i=i: box_command(i))
            box.image = photo_images[i-1]  # Referenz speichern
            box.place(x=70 + (i - 1) * 240, y=120)
    except Exception as e:
        messagebox.showerror("Fehler", f"Fehler beim Laden der Bilder: {str(e)}")

# Universelle Blink-Funktion
def blink_button(button, times):
    original_color = button.cget("background")  # Speichert ursprüngliche Farbe des Buttons
    blink_color = "yellow"  # Farbe 

    def blink(count):
        if count > 0:
            current_color = button.cget("background")
            new_color = blink_color if current_color == original_color else original_color
            button.config(background=new_color)
            root.after(500, blink, count - 1)
        else:
            button.config(background=original_color)

    blink(times)

# Hauptmenüfenster aktualisieren
def update_main_menu():
    for widget in root.winfo_children():
        widget.destroy()
    create_main_menu_widgets()

# Hauptprogramm starten
if __name__ == "__main__":
    open_main_menu()
